# Hoosier Cladding — Railway Ready
Minimal Next.js (App Router) app with:
- `/api/search` backed by `public/search_index.json`
- Dynamic `/sitemap` route
- `public/robots.txt`, `public/sitemap.xml` (optional if using route)
- Set `NEXT_PUBLIC_SITE_URL` in Railway

## Deploy
1. `railway init` or connect repo
2. Set env `NEXT_PUBLIC_SITE_URL=https://www.hoosiercladding.com`
3. Deploy
