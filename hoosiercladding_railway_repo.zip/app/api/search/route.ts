import { NextResponse } from "next/server";

let cache: Array<{ url: string; title: string; meta: string }> | null = null;

async function loadIndex() {
  if (cache) return cache;
  const base = process.env.NEXT_PUBLIC_SITE_URL || "https://www.hoosiercladding.com";
  const res = await fetch(new URL("/search_index.json", base));
  if (!res.ok) throw new Error("Failed to load search_index.json");
  cache = await res.json();
  return cache!;
}

export async function GET(req: Request) {
  const { searchParams } = new URL(req.url);
  const q = (searchParams.get("q") || "").toLowerCase().trim();
  if (!q) return NextResponse.json({ results: [] });

  const idx = await loadIndex();
  const terms = q.split(/\s+/).filter(Boolean);
  const scored = idx.map((r) => {
    const hay = `${r.title} ${r.meta}`.toLowerCase();
    const score = terms.reduce((s, t) => s + (hay.includes(t) ? 1 : 0), 0);
    return { ...r, score };
  }).filter(r => r.score > 0);

  scored.sort((a,b) => b.score - a.score);
  return NextResponse.json({ results: scored.slice(0, 25) });
}
