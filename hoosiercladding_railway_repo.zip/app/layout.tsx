export const metadata = { title: "Hoosier Cladding", description: "Siding experts in Michiana" };
export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body style={{fontFamily:'ui-sans-serif, system-ui, -apple-system, Segoe UI, Roboto, Arial'}}>
        {children}
      </body>
    </html>
  );
}
