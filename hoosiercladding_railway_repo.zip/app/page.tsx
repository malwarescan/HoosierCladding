export default function Page(){return <main style={{padding:24}}><h1>Hoosier Cladding</h1><p>Minimal Railway-ready app.</p></main>}
