import { NextResponse } from "next/server";

export async function GET() {
  const base = process.env.NEXT_PUBLIC_SITE_URL || "https://www.hoosiercladding.com";
  const res = await fetch(new URL("/search_index.json", base), { cache: "no-store" });
  const idx = await res.json() as Array<{url:string}>;
  const core = ["/", "/contact", "/service-area"];
  const today = new Date().toISOString().slice(0,10);

  const seen = new Set<string>();
  const urls = [...core.map(p => base + p), ...idx.map(i => i.url)].filter(u => {
    if (seen.has(u)) return false;
    seen.add(u);
    return true;
  });

  const xml = `<?xml version="1.0" encoding="UTF-8"?>
<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">
${urls.map(u => `  <url>
    <loc>${u}</loc>
    <lastmod>${today}</lastmod>
    <changefreq>weekly</changefreq>
    <priority>${core.includes(u.replace(base,"")) ? "0.80" : "0.70"}</priority>
  </url>`).join("\n")}
</urlset>`;

  return new NextResponse(xml, { headers: { "Content-Type": "application/xml; charset=utf-8" } });
}
